<?php
session_start();
?>
<?php
// Create connection
$con=mysqli_connect("localhost","root","","online_charity");
echo mysqli_connect_error();
?>